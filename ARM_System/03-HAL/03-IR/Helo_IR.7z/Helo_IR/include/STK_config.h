/*****************************************/
/* Author  :  Ahmed Assaf                */
/* Version :  V01                        */
/* Date    :  26 August 2020             */
/*****************************************/
#ifndef STK_CONFIG_H
#define STK_CONFIG_H


/* Options: MSTK_SRC_AHB / MSTK_SRC_AHB_8 */
#define MSTK_CLK_SRC     MSTK_SRC_AHB_8


#endif